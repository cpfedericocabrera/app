# Estudio Contable – Guía de instalación

La app son 5 archivos (`index.html`, `manifest.json`, `sw.js` y los dos íconos). No depende de Claude ni de ningún servidor pago.

---

## 1. Probarla ya (sin instalar nada)

Abrí `index.html` con doble clic. Funciona en el navegador y guarda los datos **en esa compu**.
Para instalarla en el celu y que ande sin internet, hacé el paso 2.

---

## 2. Publicarla gratis en internet (5 minutos)

**Netlify (lo más fácil):**
1. Entrá a **https://app.netlify.com/drop** y creá una cuenta gratis (podés usar tu Gmail).
2. Arrastrá **la carpeta completa** `estudio-contable` a la página.
3. Te da un link tipo `https://nombre-raro.netlify.app`. En *Site configuration → Change site name* lo cambiás por algo como `estudio-cabrera.netlify.app`.

**Instalarla:**
- **Android (Chrome):** abrí el link → menú ⋮ → *Instalar app*.
- **iPhone (Safari):** abrí el link → Compartir → *Agregar a inicio*.
- **Compu (Chrome/Edge):** ícono de instalar ⊕ en la barra de direcciones.

Queda con ícono propio, pantalla completa y funciona sin internet.

> Hasta acá, cada dispositivo guarda **sus propios datos**. Si querés los mismos datos en el celu y la compu, seguí con el paso 3.

---

## 3. Sincronizar celu y compu (opcional, gratis)

Se usa **Firebase**, de Google. El plan gratuito (Spark) alcanza de sobra para un estudio.

1. Entrá a **https://console.firebase.google.com** → *Crear un proyecto* → ponele un nombre (ej. `estudio-cabrera`) → podés desactivar Google Analytics → *Crear*.
2. **Login:** menú *Compilación → Authentication → Comenzar* → pestaña *Método de acceso* → **Correo electrónico/contraseña** → Habilitar → Guardar.
   - En *Authentication → Configuración → Dominios autorizados*, agregá tu dominio de Netlify (ej. `estudio-cabrera.netlify.app`).
3. **Base de datos:** *Compilación → Firestore Database → Crear base de datos* → ubicación **southamerica-east1 (São Paulo)** → *modo de producción* → Crear.
4. En Firestore, pestaña **Reglas**: borrá todo, pegá esto y tocá **Publicar**:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

   Así, cada usuario solo puede leer y escribir **sus propios datos**.

5. **Configuración para la app:** ⚙ *Configuración del proyecto* → abajo, en *Tus apps*, tocá el ícono **Web `</>`** → poné un apodo → *Registrar app*. Copiá el bloque `const firebaseConfig = { ... };`.
6. En la app: **Ajustes → Sincronizar celu y compu** → pegá el bloque → *Guardar y conectar* → escribí tu email y una contraseña → **Crear cuenta**.
   - Si ya tenías datos cargados en ese dispositivo, se suben solos a la nube.
7. En el otro dispositivo, pegá el mismo bloque y tocá **Ingresar** con el mismo email y contraseña.

Desde ahí, todo lo que cargues en uno aparece en el otro. Sin internet sigue funcionando y sincroniza cuando vuelve la conexión.

> La `apiKey` de Firebase **no es una contraseña**: identifica tu proyecto. Lo que protege los datos son las reglas del punto 4 y tu login.

---

## 4. Pasar los datos que cargaste en la versión de Claude

1. En la versión de Claude: *Ajustes → Descargar copia (.json)*.
2. En la nueva: *Ajustes → Restaurar copia* → elegí ese archivo.

---

## 5. Actualizar la app más adelante

Si te paso una versión nueva de `index.html`: en Netlify entrá a tu sitio → *Deploys* → arrastrá de nuevo la carpeta. Tus datos no se tocan, porque están en el dispositivo o en Firebase y no en los archivos.

## Copias de seguridad

*Ajustes → Descargar copia* una vez por mes, y guardala en tu Drive.
